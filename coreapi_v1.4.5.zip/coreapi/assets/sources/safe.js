function safe() {
    console.log("Core-API > The File will try to remove by Cheating or Exploiting or Crashing Website\This Reason in (Cheating/Exploiting/Crash-Website) are Dangerous");
};

function help() {
    console.log("Core-API > Join the Discord Server in: https://discord.gg/Wh2qet4e9D\nThis Core-API will be safety");
};

function discord() {
    console.log("Core-API > https://discord.gg/Wh2qet4e9D");
};

function apiVersions() {
    console.log("Core-API > Core-API Version: V1.5 (made for new version, This version latest is Coming Soon)");
    console.log("Core-API > Core-API Version: V1.4 (made for new version)");
    console.log("Core-API > Core-API Version: V1.3 (Verified on 1.3/1.4)");
    console.log("Core-API > Core-API Version: V1.2 (Is not made a beta)");
    console.log("Core-API > Core-API Version: V1.1 (made for old version by may - 16 - 2024)");
    console.log("Core-API > Core-API Version: V1 (made for 50 KB)");
};

function apiLayPaper() {
    console.log("Core-API > Core-API Version LayPaper: LP5 (made for new version, This version lay paper latest is Coming Soon)");
    console.log("Core-API > Core-API Version LayPaper: LP4 (made for new version)");
    console.log("Core-API > Core-API Version LayPaper: LP3 (Verified on 1.3/1.4)");
    console.log("Core-API > Core-API Version LayPaper: LP2 (Is not made a beta)");
    console.log("Core-API > Core-API Version LayPaper: LP1 (made for old version by may - 16 - 2024)");
    console.log("Core-API > Core-API Version LayPaper: LP0");
};

function corestudios() {
    console.log("Core-API > Core Studios is made Emoji Cat Yellow & SkunkPlatform created of server");
};

function npm() {
    console.log("Core-API > npm is can only use in terminal of Node.js or Visual Studio Code Terminal");
}

function purchaseFromPayPal() {
    console.log("Core-API Plus > You want purchase from the PayPal?\nYou can only be joined in discord. Use the discord()");
}