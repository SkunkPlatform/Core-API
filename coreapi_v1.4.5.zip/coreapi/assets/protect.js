function apiUpdates() {
    console.log("Core-API V1.5.2 made an items 2,5 MB");
};

function apiProtect() {
    console.log("1.3/1.4 made for protectors of Core-API");
};