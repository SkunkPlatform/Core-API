// Import the plugin metadata from plugin.json
const { name, description, version, enabled } = require("./plugin.json");

// Function to display plugin help information
function mypluginHelp() {
    console.log(`Plugin Name: ${name}`);
    console.log(`Description: ${description}`);
    console.log(`Version: ${version}`);
    console.log(`Enabled: ${enabled}`);
    console.log("Core Plugins > Type the Plugin Information here");
};

// You can add more functions here for the plugin's functionality
function initializePlugin() {
    if (enabled) {
        console.log(`${name} (v${version}) is now enabled.`);
        // Add your plugin initialization code here
    } else {
        console.log(`${name} is currently disabled.`);
    }
}

// Example usage of the plugin functions
initializePlugin();
mypluginHelp();

// Export the functions if needed for external use
module.exports = {
    mypluginHelp,
    initializePlugin
};
