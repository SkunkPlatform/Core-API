function emojicatTikTok() {
    console.log("This Emoji Cat isn't available");
};

function getnodeid() {
    var randomNodeId = Math.floor(Math.random() * 1000);
    console.log("Node ID: " + randomNodeId);
}

function getapiversion() {
    if (process.argv.length > 2) {
        var version = process.argv[2];
        if (version === "V1.1") {
            console.log("Core-API Version Result: https://www.mediafire.com/file/6j695l9z62xzmou/coreapi_v1.1.zip/file");
        } else if (version === "v1.3") {
            console.log("Core-API Version Result: https://www.mediafire.com/file/66yyrvl35fqdrk0/coreapi.zip/file");
        } else if (version === "v1.4") {
            console.log("Core-API > You are on this version");
        } else if (version === "v1.5") {
            console.log("This version 1.5 is coming soon and are all the Core-API Updates in V1.5");
        } else {
            console.log("Invalid API version, use on V1.1 or V1.4");
        }
    } else {
        console.log("Usage: node script.js <API version>");
    }
}

function helpNode() {
    console.log("Help Node > getnodeid(), getapiversion()");
}