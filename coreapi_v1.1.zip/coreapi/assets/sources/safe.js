function safe() {
    console.log("The File will try to remove by Cheating or Exploiting or Crashing Website");
};