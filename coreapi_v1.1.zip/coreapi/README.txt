1. Install from the npm init -y or npm init with Node.js to use this Core API

2. Put your Website on File of API

3. Open the Console or Press F12 to Open Console

4. You can work this