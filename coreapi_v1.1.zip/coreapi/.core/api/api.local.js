console.log("Use 'npm init' to install the node.js");

console.log("SkunkPlatform TikTok: https://www.tiktok.com/@skunk.platform");
console.log("SkunkPlatform TikTok: https://www.tiktok.com/@skunk.platform");

async function pcausa(target, url) {
    window.open(url, target);
    console.log("This pcausa is openning");
};