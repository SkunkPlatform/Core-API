// module of core.js

const api = require("./api.local");

async function vscodeRun() {
    //vscode-run-html
    console.log("Website Verification > You can verify on verify(name)");
    console.log("Core > Welcome to the Core-Studio\nIs a made for the control() to work");
    console.log("Core > The Core API requires Node.js to use this");
}

async function verify(webname) {
    if (document.title === webname) {
        console.log("Website Verification > Your website is verified, but you can control the website from control('help')");
    }
}

async function control(type, value1, value2) {
    if (type === "help") {
        console.log("Help > Controls a website for using an");
    } else if (type === "reset") {
        console.log("Controller > Reloading website...");
        window.location.reload();
    } else if (type === "addelement") {
        console.log("Controller > Creating element...");
        var newElement = document.createElement(value1);

        if (value2.id) newElement.id = value2.id;
        if (value2.name) newElement.name = value2.name;
        if (value2.classname) newElement.className = value2.classname;
        if (value2.class) newElement.classList.add(value2.class);

        document.body.appendChild(newElement);
        console.log("Controller > Element added to the page.");
    } else if (type === "support") {
        console.log("Controller Support > Controller made to control a website");
    } else if (type === "open-core") {
        document.body.innerHTML = `
        <style>
            body {
                background-color: #444;
                color: white;
            };

            a {
                color: white;
            }

            div {
                background-color: #555;
                color: white;
            }

            button {
                background-color: #222;
                color: white;
                display: flex;

            }
        </style>

        <a href="https://www.tiktok.com/@skunk.platform" target="_blank">SkunkPlatform TikTok</a>
        <a href="https://www.youtube.com/channel/UCoubQ4ccU3l3Wcr-Vrd8RvQ" target="_blank">SkunkPlatform YouTube</a>
        <button id="reloadweb">Reload Website</button>

        <script>
            document.getElementById("reloadweb").addEventListener("click",function(){
                window.location.reload()
            });
        </script>
        `;
        document.head.innerHTML = `
        <title>Core-Studio</title>
        <link rel="shortcut icon" href="icon.png">
        `
    } else if (type === "search-website") {
        console.log("Controller > Searching Website...");
        if (value1 === undefined && value2 === undefined) {
            console.log(`Usage: control("search-website", "_blank", "https://www.example.com")`)
        }
        if (!value1 === undefined && value2 === undefined) {
            pcausa(value1, value2);
        }
    }
}
