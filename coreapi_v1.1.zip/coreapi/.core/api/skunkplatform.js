function skunkplatformtiktok() {
    console.log("Openning...");
    window.open("https://www.tiktok.com/@skunk.platform");
}
