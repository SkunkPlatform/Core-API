const api = require("./.core/api/api");
const apiLocal = require("./.core/api/api.local");
const sp = require("./.core/api/skunkplatform");

const coreapi = {};

coreapi.run = function() {
    vscodeRun();
};